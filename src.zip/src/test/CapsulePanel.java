package test;

import javax.swing.*;
import java.awt.*;

public class CapsulePanel extends JPanel {

    public CapsulePanel() {
        setOpaque(false); // Important! Otherwise background will be transparent
        setPreferredSize(new Dimension(200, 50)); // Set default preferred size here
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);

        Graphics2D g2 = (Graphics2D) g.create();
        g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON); // Smooth edges

        int width = getWidth();   // dynamically get current width
        int height = getHeight(); // dynamically get current height
        int arc = height;         // arc height = height for capsule shape

        g2.setColor(new Color(255, 140, 0)); // Orange color
        g2.fillRoundRect(0, 0, width, height, arc, arc);

        g2.dispose();
    }
}