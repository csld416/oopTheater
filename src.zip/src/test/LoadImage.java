package test;

import javax.swing.*;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.File;
import javax.imageio.ImageIO;

public class LoadImage {

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            JFrame frame = new JFrame("Load Oppenheimer Poster");
            frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            frame.setSize(400, 600);
            frame.setLocationRelativeTo(null); // Center on screen

            JPanel panel = new JPanel();
            panel.setBackground(Color.WHITE);
            panel.setLayout(new BorderLayout());

            try {
                BufferedImage img = ImageIO.read(new File("src/MoviePosters/Oppenheimer.jpg")); // Path to your image
                Image scaled = img.getScaledInstance(300, 450, Image.SCALE_SMOOTH);
                JLabel label = new JLabel(new ImageIcon(scaled));
                label.setHorizontalAlignment(JLabel.CENTER);
                panel.add(label, BorderLayout.CENTER);
            } catch (Exception e) {
                JLabel error = new JLabel("Failed to load image");
                error.setForeground(Color.RED);
                error.setHorizontalAlignment(JLabel.CENTER);
                panel.add(error, BorderLayout.CENTER);
            }

            frame.add(panel);
            frame.setVisible(true);
        });
    }
}