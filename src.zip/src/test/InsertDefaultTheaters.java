package test;

import connection.DatabaseConnection;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class InsertDefaultTheaters {

    private static boolean theaterExists(Connection conn, String name) throws Exception {
        String checkSql = "SELECT COUNT(*) FROM Theaters WHERE name = ?";
        try (PreparedStatement checkStmt = conn.prepareStatement(checkSql)) {
            checkStmt.setString(1, name);
            try (ResultSet rs = checkStmt.executeQuery()) {
                rs.next();
                return rs.getInt(1) > 0;
            }
        }
    }

    public static void main(String[] args) {
        try (Connection conn = new DatabaseConnection().getConnection()) {

            // name, type, capacity
            String[][] theaters = {
                {"Room A", "大型廳", "100"},
                {"Room B", "大型廳", "90"},
                {"Room C", "小型廳", "50"}
            };

            String insertSql = "INSERT INTO Theaters (name, type, capacity, is_active) VALUES (?, ?, ?, 1)";
            try (PreparedStatement insertStmt = conn.prepareStatement(insertSql)) {
                int inserted = 0;

                for (String[] theater : theaters) {
                    String name = theater[0];
                    String type = theater[1];
                    int capacity = Integer.parseInt(theater[2]);

                    if (!theaterExists(conn, name)) {
                        insertStmt.setString(1, name);
                        insertStmt.setString(2, type);
                        insertStmt.setInt(3, capacity);
                        insertStmt.executeUpdate();
                        inserted++;
                    } else {
                        System.out.println("⚠ 已存在放映廳：" + name);
                    }
                }

                System.out.println("✅ 插入完成，共新增 " + inserted + " 筆資料");
            }

        } catch (Exception e) {
            System.err.println("❌ 錯誤：" + e.getMessage());
            e.printStackTrace();
        }
    }
}