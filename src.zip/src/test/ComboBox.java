package test;

import javax.swing.*;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

public class ComboBox extends JPanel {

    private final JLabel displayLabel = new JLabel("請選擇分級");
    private final JPopupMenu popup = new JPopupMenu();

    public ComboBox(String[] items) {
        setLayout(new BorderLayout());
        setBackground(new Color(230, 230, 230));
        setBorder(BorderFactory.createLineBorder(Color.GRAY));
        setPreferredSize(new Dimension(200, 30));

        displayLabel.setHorizontalAlignment(SwingConstants.LEFT);
        displayLabel.setBorder(BorderFactory.createEmptyBorder(5, 10, 5, 5));
        add(displayLabel, BorderLayout.CENTER);

        // Add dropdown indicator
        JLabel arrow = new JLabel("▼");
        arrow.setBorder(BorderFactory.createEmptyBorder(0, 0, 0, 10));
        add(arrow, BorderLayout.EAST);

        // Populate popup menu
        for (String item : items) {
            JMenuItem menuItem = new JMenuItem(item);
            menuItem.setFont(new Font("Microsoft JhengHei", Font.PLAIN, 14));
            menuItem.addActionListener(e -> {
                displayLabel.setText(item);
                popup.setVisible(false);
            });
            popup.add(menuItem);
        }

        // Toggle popup on click
        addMouseListener(new MouseAdapter() {
            @Override
            public void mousePressed(MouseEvent e) {
                popup.show(ComboBox.this, 0, getHeight());
            }
        });
    }

    public String getSelectedItem() {
        return displayLabel.getText();
    }

    // Test
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            JFrame frame = new JFrame("Custom ComboBox with JPanel");
            frame.setSize(400, 200);
            frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            frame.setLayout(new FlowLayout());

            String[] ratings = {"普遍級", "保護級", "輔12", "輔15", "限制級"};
            ComboBox customBox = new ComboBox(ratings);

            frame.add(customBox);
            frame.setLocationRelativeTo(null);
            frame.setVisible(true);
        });
    }
}