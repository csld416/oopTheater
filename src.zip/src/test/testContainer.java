package test;

import Main.help.ArrowPanel;
import Main.help.topbarPanel.StaffPanel;

import javax.swing.*;
import java.awt.*;

public class testContainer {

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            JFrame frame = new JFrame("Test");
            frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            frame.setSize(300, 200);
            frame.setLocationRelativeTo(null);
            frame.setLayout(new FlowLayout(FlowLayout.CENTER, 30, 40));

            CapsulePanel capsule = new CapsulePanel();
            capsule.setBounds(50, 50, 200, 50); // Width much larger than height

            frame.add(capsule);

            frame.setVisible(true);
        });
    }
}
