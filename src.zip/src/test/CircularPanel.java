package test;

import javax.swing.*;
import java.awt.*;

public class CircularPanel extends JPanel {

    public CircularPanel(int diameter, Color color) {
        setPreferredSize(new Dimension(diameter, diameter));
        setBackground(color);
        setOpaque(false); // Important: allows custom shape
    }

    @Override
    protected void paintComponent(Graphics g) {
        // Enable antialiasing for smooth edges
        Graphics2D g2 = (Graphics2D) g.create();
        g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

        // Draw circle
        g2.setColor(getBackground());
        g2.fillOval(0, 0, getWidth(), getHeight());

        g2.dispose();
    }

    @Override
    public boolean contains(int x, int y) {
        // Only accept clicks inside the circle
        int radius = getWidth() / 2;
        int centerX = radius;
        int centerY = radius;
        return (Math.pow(x - centerX, 2) + Math.pow(y - centerY, 2)) <= Math.pow(radius, 2);
    }
}