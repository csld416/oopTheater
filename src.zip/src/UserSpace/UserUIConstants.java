/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package UserSpace;


/**
 *
 * @author csld
 */
public class UserUIConstants {
    
    public static final int SLOT_HEIGHT = 80;
    
    
    public static final int ICON_SIZE = 30;
    
    public static final int ICON_X = 40;
    public static final int ICON_Y = (SLOT_HEIGHT - ICON_SIZE) / 2;
    
    public static final int TEXT_X = ICON_X + 55;
    
}
